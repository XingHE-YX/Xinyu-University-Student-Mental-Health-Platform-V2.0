"""CloudBase document database adapters."""
