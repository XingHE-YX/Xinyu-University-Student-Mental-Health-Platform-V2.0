"""Minimal audit event writers."""
