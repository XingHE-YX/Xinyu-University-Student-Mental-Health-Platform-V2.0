"""HTTP route adapters."""
