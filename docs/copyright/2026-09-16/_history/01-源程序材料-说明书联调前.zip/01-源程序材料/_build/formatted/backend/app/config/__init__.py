"""Environment configuration models."""
