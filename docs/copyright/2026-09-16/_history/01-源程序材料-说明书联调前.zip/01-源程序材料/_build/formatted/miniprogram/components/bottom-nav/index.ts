Component({
  properties: { current: { type: String, value: 'today' } },
  data: {
    items: [
      { key: 'today', label: '今日' },
      { key: 'assessment', label: '自测' },
      { key: 'treehole', label: '树洞' },
      { key: 'my', label: '我的' },
    ],
  },
  methods: {
    navigate(event: WechatMiniprogram.BaseEvent) {
      const key = (event.currentTarget as WechatMiniprogram.Target).dataset
        .key as string;
      const routes: Record<string, string> = {
        today: '/pages/today/index',
        assessment: '/pages/assessment-center/index',
        treehole: '/pages/treehole/index',
        my: '/pages/my/index',
      };
      if (routes[key] && key !== this.data.current)
        wx.switchTab({ url: routes[key] });
    },
  },
});
