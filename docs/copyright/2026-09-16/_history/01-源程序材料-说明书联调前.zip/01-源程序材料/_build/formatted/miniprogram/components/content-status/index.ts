Component({ properties: { status: String } });
