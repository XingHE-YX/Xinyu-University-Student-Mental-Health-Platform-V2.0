Component({ properties: { status: String } })
